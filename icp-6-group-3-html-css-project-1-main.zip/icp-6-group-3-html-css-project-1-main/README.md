# icp-6-group-3-html-css-project-1

## Tagline
Your one-stop shop for all your fashion needs!

## URL
https://glitzzjwellers.vercel.app/

## Screenshots
![Screenshot 1](./img/homepage.jpeg)
![Screenshot 2](./img/loginpage.jpeg)
![Screenshot 3](./img/bestsellerpage.jpeg)
![Screenshot 4](./img/necklacepage.jpeg)
![Screenshot 5](./img/banglespage.jpeg)
![Screenshot 6](./img/earringspage.jpeg)
![Screenshot 7](./img/pendantpage.png)
![Screenshot 8](./img/contactpage.jpeg)


## Use of Project
To use jwellery Shop Website, simply visit the URL provided above.Online jewellery makes your choice much easier . and also it reduces the travelling expences by making it online.


## Description
To Make this website We have used HTML abd CSS. Our website is user-friendly. Online jewellery makes your choice much easier by allowing you to quickly compare the detailed descriptions and prices of the pieces you are interested in.


## Real Life Use
jewellery Shop Website can be used by anyone looking to purchase high-quality fashion items. our website is here to make your shopping experience enjoyable and convenient.

## Future Scope
We have exciting plans for the future of jewellery Shop Website,
- Introducing a mobile app for on-the-go shopping.
- Implementing user reviews and ratings for product feedback.